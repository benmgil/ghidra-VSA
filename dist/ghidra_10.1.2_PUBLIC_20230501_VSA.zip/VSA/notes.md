# NOTES:
CFG
	nodes are basic blocks
	edges are possible control flow transfers between them
	indirect jumps - no hardcoded target. can be
		computed
		context sensitive (callbacks)
		object sensitive (polymorphism)

VSA
	attempts tight over approximation of program state at any given point
	memory and registers


Normalization: IDA will split basic blocks if another block jumps into the middle of it. This is called basic block normalization, and angr does not do it by default since it is unnecessary for most static analyses. You may enable it by passing normalize=True to the CFG analysis

p.loader.min_addr can be used to get offset?




#BIG THINGS
Figure out DDG. Do we even need it?
Get rid of atoi hook somehow



# QUESTIONS
vfgnode.final_states number depends on context sensitivity level?
auto_load_libs?

What does .resolved do for BVs
WHAT DO THE VFGNODE REPRs MEAN (0xXXX@0xXXX)

# THINGS TO DO:

INVESTIGATE CONTEXT SENSITIVITY LEVEL
RECURSION ERROR SOLUTION
DO WE WANT TO GET THE VALUE AT THE END OF THE BLOCK OR AT THE BEGINNING? OUTPUT SHOULD BE CLEAR WHICHEVER WAY
BackendVSA? Frontend VSA?
REEXAMINE DDG
CFGFAST or CFGEMULATED
	>https://docs.angr.io/built-in-analyses/cfg
	>https://docs.angr.io/built-in-analyses/backward_slice
ENSURE TARGET INSTR IS IN CFG



# FEATURE IDEAS:
pickling so we dont recompute or look at speedup
> https://docs.angr.io/advanced-topics/speed
We can maybe use a loader backend to load the pcode instead of the binary itself


https://docs.angr.io/introductory-errata/faq#why-isnt-symbolic-execution-doing-the-thing-i-want

158 243
111281 241565


#Qs

ghidra has diff instructions than ida (reg offset at 1234)



#UI THINGS

clean up angr ouput

maybe get operands and put them in the popup menu

arguments to binary?

no input validation for registers

make termination happen faster






research
	scheduling thing
	oral report
		35-45 min
		problems addressed by work
		describes what was done
		explains any results achieved
		schedule 4-6 weeks ahead
		2 hour block of time
	writeup
		required at least a week b4
		project title and abstract to coordinator at least a week b4
		at least 2 pages
		formatted in any way
		summarize work perfored and should describe any products of the work such as hardware, software, theorems or experimental results, as well as how to access any artifacts (eg repo or websites) produced
		turn in approved writeup in electronic form to CSE grad coordinator


what i learned
	firmware architecture, squashfs etc.



compile and start run on boa
systems
paper
look at other firmware


GIFT FOR OREN AND ALEX
RSVP TO SETH



print ill be waiting



CAN DO
	band
	research

CANT DO YET
	networks course eval
	systems discussion post

OTHER PEOPLE REQUIRED
	recording
	ai final project



phone
decide jake
move out



more complex binary
	-maybe strncpy a string to a diff location and see if it still works
Make it work with user input instead of just keyword ref

print taints that are found instead of how many

asus/fc - boa stuff
WNR - webupg stuff
